<?php 

echo "suite a une probleme de reseau votre msg n'est pas envoyer <a href='page1_form.php'>clickez ici</a> pour faire un devis";



?>